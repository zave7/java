package com.kitri.cafe.util;

public class CafeConstance {
	public static int ARTICLE_SIZE = 20;
	public static int PAGE_SIZE = 10;
}